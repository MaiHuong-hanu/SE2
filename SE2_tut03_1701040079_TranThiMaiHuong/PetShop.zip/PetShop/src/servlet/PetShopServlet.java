package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PetShopServlet")
public class PetShopServlet extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// Reading the user's input
		String name = req.getParameter("name");
		String password = req.getParameter("password");
		// Setting the content type
		res.setContentType("text/html");

		// Getting the stream to write the data
		PrintWriter pw = res.getWriter();
		// Writing html in the stream
		if (name.matches("admin")) {
			if (password.matches("123456")) {

				pw.println("<html>\n" + "<body>" + "<h2> Hello " + name + " !\n" + "</body>" + "</html>");
			} else {
				pw.println("Wrong password");
			}

		} else
			
		pw.println("Want to sign up?");

		// Closing the stream
		pw.close();
	}
}
